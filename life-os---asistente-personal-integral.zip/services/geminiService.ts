
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeLifeData = async (data: any) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analiza los siguientes datos de vida del usuario para enero de 2026. 
      Toma en cuenta que la moneda es SOLES PERUANOS (S/.).
      El usuario tiene acceso de SUPERUSUARIO, sin restricciones.
      Proporciona 3 ideas accionables (finanzas, productividad y bienestar). 
      Responde en ESPAÑOL.
      Formatea la respuesta como un objeto JSON con una matriz 'insights' de objetos {title, description, priority}.
      
      Datos: ${JSON.stringify(data)}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            insights: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                  priority: { type: Type.STRING }
                },
                required: ['title', 'description', 'priority']
              }
            }
          }
        }
      }
    });

    return JSON.parse(response.text || '{"insights": []}');
  } catch (error) {
    console.error("Error en Análisis Gemini:", error);
    return { insights: [{ title: "Optimización Pro", description: "Sistema operando en modo Superusuario. Registra más datos para análisis profundo.", priority: "Baja" }] };
  }
};

export const getQuickAdvice = async (prompt: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      systemInstruction: "Eres 'Life OS Intelligence', el núcleo de un sistema de gestión personal avanzada. Tienes acceso total a los datos. Mantén las respuestas breves, ejecutivas y altamente prácticas. La moneda es Soles (S/.). Responde siempre en español."
    }
  });
  return response.text;
};
