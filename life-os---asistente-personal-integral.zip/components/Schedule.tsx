
import React, { useState } from 'react';
import { Calendar as CalendarIcon, Clock, Mail, CheckCircle2, MoreHorizontal, Plus, Link as LinkIcon } from 'lucide-react';
import { MOCK_TASKS } from '../constants';

const Schedule: React.FC = () => {
  const [tasks, setTasks] = useState(MOCK_TASKS);
  
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-slate-900">Agenda y Tiempo</h2>
          <p className="text-slate-500 mt-1">Sincronizado con Google Calendar y notificaciones de Gmail.</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 bg-white text-slate-700 border border-slate-200 px-4 py-2 rounded-xl font-bold shadow-sm hover:bg-slate-50 transition-all">
            <LinkIcon size={18} />
            <span className="hidden sm:inline">Sincronizar Calendario</span>
          </button>
          <button className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-bold shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all">
            <Plus size={20} />
            <span>Nueva Tarea</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Lado Izquierdo: Mini Vista Calendario */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
            <h3 className="font-bold mb-4 flex items-center justify-between">
              Enero 2026
              <MoreHorizontal size={18} className="text-slate-400" />
            </h3>
            <div className="grid grid-cols-7 gap-2 text-center text-[10px] font-bold text-slate-400 mb-2 uppercase tracking-widest">
              <span>D</span><span>L</span><span>M</span><span>M</span><span>J</span><span>V</span><span>S</span>
            </div>
            <div className="grid grid-cols-7 gap-1">
              {Array.from({ length: 31 }).map((_, i) => (
                <div 
                  key={i} 
                  className={`aspect-square flex items-center justify-center rounded-lg text-xs font-semibold cursor-pointer transition-colors ${i + 1 === 19 ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 hover:bg-slate-50'}`}
                >
                  {i + 1}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-indigo-50 border border-indigo-100 rounded-3xl p-6">
             <div className="flex items-center gap-2 text-indigo-700 mb-3">
               <Mail size={18} />
               <h4 className="font-bold text-sm">Integración Gmail</h4>
             </div>
             <p className="text-xs text-indigo-600 leading-relaxed mb-4">
               Tienes 3 correos sin leer con posibles tareas de acción.
             </p>
             <div className="space-y-2">
               <div className="bg-white p-2 rounded-lg shadow-sm border border-indigo-100 flex items-center gap-3">
                 <div className="w-1 h-6 bg-orange-400 rounded-full" />
                 <span className="text-[10px] font-medium text-slate-700 truncate">Feedback Proyecto - CEO</span>
               </div>
               <div className="bg-white p-2 rounded-lg shadow-sm border border-indigo-100 flex items-center gap-3">
                 <div className="w-1 h-6 bg-indigo-400 rounded-full" />
                 <span className="text-[10px] font-medium text-slate-700 truncate">Renovación de Suscripción</span>
               </div>
             </div>
          </div>
        </div>

        {/* Centro: Lista Principal de Tareas */}
        <div className="lg:col-span-3 space-y-6">
           <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
             <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
               <h3 className="font-bold">Tareas Activas</h3>
               <div className="flex gap-2">
                 <span className="text-xs font-bold px-2 py-1 bg-slate-100 text-slate-500 rounded-md cursor-pointer">TODAS</span>
                 <span className="text-xs font-bold px-2 py-1 bg-indigo-50 text-indigo-600 rounded-md cursor-pointer">TRABAJO</span>
                 <span className="text-xs font-bold px-2 py-1 bg-slate-100 text-slate-500 rounded-md cursor-pointer">PERSONAL</span>
               </div>
             </div>
             <div className="divide-y divide-slate-100">
               {tasks.map(task => (
                 <div key={task.id} className="p-6 flex flex-col sm:flex-row sm:items-center justify-between group hover:bg-slate-50 transition-colors gap-4">
                   <div className="flex items-start gap-4">
                     <button className={`shrink-0 mt-1 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${task.status === 'Completada' ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-slate-300 text-transparent hover:border-indigo-400'}`}>
                       <CheckCircle2 size={14} />
                     </button>
                     <div>
                       <h4 className={`font-bold transition-all ${task.status === 'Completada' ? 'text-slate-400 line-through' : 'text-slate-800'}`}>
                         {task.title}
                       </h4>
                       <div className="flex items-center gap-3 mt-1">
                         <span className="flex items-center gap-1 text-[10px] font-bold text-slate-400 uppercase tracking-tighter">
                           <CalendarIcon size={12} />
                           {task.dueDate}
                         </span>
                         <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded ${task.priority === 'Alta' ? 'bg-rose-50 text-rose-600' : 'bg-blue-50 text-blue-600'}`}>
                           {task.priority}
                         </span>
                         {task.source === 'Calendar' && (
                           <span className="flex items-center gap-1 text-[10px] font-bold text-indigo-500">
                             <Clock size={12} />
                             Sincronizado
                           </span>
                         )}
                       </div>
                     </div>
                   </div>
                   <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                     <button className="p-2 text-slate-400 hover:text-slate-600">
                       <MoreHorizontal size={18} />
                     </button>
                   </div>
                 </div>
               ))}
             </div>
             <div className="p-4 bg-slate-50 flex justify-center border-t border-slate-100">
               <button className="text-sm font-bold text-slate-400 hover:text-indigo-600 transition-colors">
                 Cargar tareas completadas anteriores
               </button>
             </div>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-900 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
                <div className="relative z-10">
                  <h3 className="font-bold text-lg mb-2">Sesión de Enfoque</h3>
                  <p className="text-slate-400 text-sm mb-6 leading-relaxed">Mejora tu productividad usando un ciclo Pomodoro de 25/5.</p>
                  <button className="px-6 py-2.5 bg-indigo-500 hover:bg-indigo-400 text-white font-bold rounded-xl shadow-lg shadow-indigo-500/20 transition-all">
                    Iniciar Temporizador
                  </button>
                </div>
                <div className="absolute top-0 right-0 p-4 text-indigo-800 opacity-20">
                  <Clock size={100} />
                </div>
              </div>

              <div className="bg-emerald-600 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
                <div className="relative z-10">
                  <h3 className="font-bold text-lg mb-2">Resumen Semanal</h3>
                  <p className="text-emerald-100 text-sm mb-6 leading-relaxed">Has completado 18 tareas esta semana. ¡Es un 15% más que la semana pasada!</p>
                  <button className="px-6 py-2.5 bg-white text-emerald-700 font-bold rounded-xl shadow-lg transition-all">
                    Ver Reporte
                  </button>
                </div>
                <div className="absolute bottom-0 right-0 p-4 text-emerald-800 opacity-20">
                  <TrendingUpIcon />
                </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

const TrendingUpIcon = () => (
  <svg className="w-24 h-24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M22 7l-8.5 8.5L9 11l-7 7" />
    <path d="M16 7h6v6" />
  </svg>
);

export default Schedule;
