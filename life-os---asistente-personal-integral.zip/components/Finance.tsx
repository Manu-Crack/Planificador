
import React, { useState } from 'react';
import { Plus, Wallet, PieChart, TrendingDown, ArrowRight, Bell, Calculator, Download, Calendar } from 'lucide-react';
import { CATEGORIES, MOCK_BUDGETS } from '../constants';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const Finance: React.FC = () => {
  const [budgets, setBudgets] = useState(MOCK_BUDGETS);
  const [viewType, setViewType] = useState<'mensual' | 'semanal'>('mensual');
  
  const totalLimit = budgets.reduce((a, b) => a + b.limit, 0);
  const totalSpent = budgets.reduce((a, b) => a + b.spent, 0);

  const chartData = budgets.map(b => ({
    name: b.category,
    spent: viewType === 'mensual' ? b.spent : b.spent / 4,
    limit: viewType === 'mensual' ? b.limit : b.limit / 4,
    percent: (b.spent / b.limit) * 100
  }));

  const avgDailySpent = (totalSpent / 30).toFixed(2);
  const projectedEnd = (totalSpent * (viewType === 'mensual' ? 1 : 0.25)).toLocaleString();
  const savingsProjected = (totalLimit - totalSpent).toLocaleString();

  return (
    <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-black tracking-tight text-slate-900 dark:text-white uppercase">Finanzas Base (S/.)</h2>
          <p className="text-slate-500 mt-1">Control de capital en tiempo real y análisis proactivo.</p>
        </div>
        <div className="flex flex-wrap gap-3">
           <div className="bg-slate-100 dark:bg-slate-800 p-1 rounded-xl flex gap-1">
             <button 
              onClick={() => setViewType('mensual')}
              className={`px-4 py-2 rounded-lg text-xs font-black uppercase transition-all ${viewType === 'mensual' ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
             >
               Mensual
             </button>
             <button 
              onClick={() => setViewType('semanal')}
              className={`px-4 py-2 rounded-lg text-xs font-black uppercase transition-all ${viewType === 'semanal' ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
             >
               Semanal
             </button>
           </div>
           <button className="flex items-center gap-2 bg-white dark:bg-slate-900 text-slate-900 dark:text-white border-2 border-slate-900 dark:border-slate-700 px-5 py-2.5 rounded-xl font-black text-xs uppercase hover:bg-slate-50 dark:hover:bg-slate-800 transition-all">
            <Download size={18} />
            <span className="hidden sm:inline">Exportar S/.</span>
          </button>
          <button className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-black text-xs uppercase shadow-xl shadow-indigo-200 dark:shadow-none hover:bg-indigo-700 transition-all">
            <Plus size={20} />
            <span>Nuevo Registro</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden relative group">
            <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:scale-110 transition-transform dark:text-white">
              <Wallet size={200} />
            </div>
            <div className="flex flex-col sm:flex-row justify-between gap-6 mb-12 relative z-10">
              <div>
                <p className="text-slate-400 font-black uppercase text-[10px] tracking-widest mb-2">Flujo {viewType} Soles</p>
                <div className="flex items-baseline gap-2">
                  <span className="text-4xl font-black text-slate-900 dark:text-white">S/. {totalSpent.toLocaleString()}</span>
                  <span className="text-slate-400 font-bold">/ S/. {totalLimit.toLocaleString()}</span>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="bg-slate-50 dark:bg-slate-800 px-4 py-3 rounded-2xl text-center border border-slate-100 dark:border-slate-700 min-w-[100px]">
                  <p className="text-[10px] text-slate-400 font-black uppercase mb-1">Ahorros</p>
                  <p className="text-lg font-black text-emerald-500">S/. 1,250</p>
                </div>
                <div className="bg-slate-50 dark:bg-slate-800 px-4 py-3 rounded-2xl text-center border border-slate-100 dark:border-slate-700 min-w-[100px]">
                  <p className="text-[10px] text-slate-400 font-black uppercase mb-1">Deuda</p>
                  <p className="text-lg font-black text-rose-500">S/. 400</p>
                </div>
              </div>
            </div>

            <div className="h-64 w-full relative z-10">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={darkModeSupported() ? '#1e293b' : '#f1f5f9'} />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 700}} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 700}} />
                  <Tooltip 
                    cursor={{fill: darkModeSupported() ? '#1e293b' : '#f8fafc'}}
                    contentStyle={{borderRadius: '16px', border: 'none', backgroundColor: darkModeSupported() ? '#0f172a' : '#fff', color: darkModeSupported() ? '#fff' : '#000', boxShadow: '0 25px 50px -12px rgb(0 0 0 / 0.1)'}}
                    formatter={(value) => [`S/. ${value}`, 'Monto']}
                  />
                  <Bar dataKey="spent" radius={[6, 6, 0, 0]} barSize={40}>
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.percent > 90 ? '#ef4444' : (darkModeSupported() ? '#6366f1' : '#0f172a')} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
            <h3 className="text-lg font-black uppercase tracking-tight mb-6 dark:text-white">Desglose {viewType} Soles</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {budgets.map(budget => {
                const isWarning = budget.spent / budget.limit > 0.9;
                const displaySpent = viewType === 'mensual' ? budget.spent : (budget.spent / 4).toFixed(2);
                const displayLimit = viewType === 'mensual' ? budget.limit : (budget.limit / 4).toFixed(2);
                
                return (
                  <div key={budget.category} className={`p-5 rounded-2xl border ${isWarning ? 'border-rose-200 bg-rose-50 dark:bg-rose-900/10 dark:border-rose-900/50' : 'border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50'} transition-all hover:scale-[1.02] cursor-pointer`}>
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h4 className="font-black text-slate-900 dark:text-white uppercase text-xs">{budget.category}</h4>
                        <p className={`text-[10px] font-black ${isWarning ? 'text-rose-500' : 'text-slate-400'} uppercase tracking-widest`}>
                          {isWarning ? 'ATENCIÓN REQUERIDA' : 'ESTADO ESTABLE'}
                        </p>
                      </div>
                      {isWarning && <Bell size={18} className="text-rose-500 animate-pulse" />}
                    </div>
                    <div className="flex justify-between text-xs mb-2 font-bold dark:text-slate-300">
                      <span>S/. {displaySpent} gastado</span>
                      <span className="text-slate-400">S/. {displayLimit} máx</span>
                    </div>
                    <div className="h-2 w-full bg-white dark:bg-slate-700 rounded-full overflow-hidden border border-slate-200/50 dark:border-slate-600">
                      <div 
                        className={`h-full transition-all duration-1000 ${isWarning ? 'bg-rose-500' : 'bg-indigo-600'}`} 
                        style={{ width: `${Math.min(100, (budget.spent/budget.limit)*100)}%` }} 
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="space-y-8">
           <div className="bg-slate-900 text-white rounded-3xl p-8 border border-slate-800 shadow-2xl overflow-hidden relative group">
             <div className="relative z-10">
               <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center mb-6">
                 <Calculator size={24} className="text-indigo-400" />
               </div>
               <h3 className="text-xl font-black mb-4 uppercase tracking-tighter">Analizador de Tendencias</h3>
               <p className="text-slate-400 text-sm mb-8 leading-relaxed">
                 Admin, tu gasto promedio diario es <span className="text-white font-bold">S/. {avgDailySpent}</span>. 
                 A este ritmo, tu proyección {viewType} es <span className="text-white font-bold">S/. {projectedEnd}</span>.
                 <br/><br/>
                 <span className={`${viewType === 'mensual' ? 'text-emerald-400' : 'text-indigo-400'} font-bold`}>Estado: {savingsProjected} Soles disponibles para inversión.</span>
               </p>
               <button className="w-full flex items-center justify-center gap-2 py-3 bg-white text-slate-900 rounded-xl font-black text-xs uppercase hover:bg-slate-100 transition-all shadow-lg group-hover:scale-105">
                 OPTIMIZAR CARTERA
                 <ArrowRight size={16} />
               </button>
             </div>
             <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-indigo-500/20 rounded-full blur-3xl" />
           </div>

           <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
             <div className="flex items-center gap-3 mb-6">
               <div className="p-2 bg-slate-100 dark:bg-slate-800 rounded-lg text-slate-900 dark:text-white">
                 <Calendar size={20} />
               </div>
               <h3 className="font-black uppercase text-xs tracking-widest text-slate-900 dark:text-white">Historial Central</h3>
             </div>
             <div className="space-y-4">
                {[
                  { label: 'Oxxo Miraflores', date: 'Hoy, 10:30 AM', amount: '-S/. 5.50', category: 'Alimentación' },
                  { label: 'Yape a Contacto', date: 'Hoy, 09:15 AM', amount: '-S/. 25.00', category: 'Otros' },
                  { label: 'Cabify Premium', date: 'Ayer, 8:15 PM', amount: '-S/. 18.20', category: 'Transporte' },
                  { label: 'Sedapal Online', date: '15 Ene, 2026', amount: '-S/. 84.00', category: 'Servicios' },
                ].map((item, i) => (
                  <div key={i} className="flex justify-between items-center group cursor-pointer p-1 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg transition-all">
                    <div>
                      <p className="text-sm font-bold text-slate-800 dark:text-slate-100 group-hover:text-indigo-600 transition-colors">{item.label}</p>
                      <p className="text-[10px] text-slate-400 font-bold uppercase">{item.date}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-black text-slate-900 dark:text-white">{item.amount}</p>
                      <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">{item.category}</p>
                    </div>
                  </div>
                ))}
             </div>
             <button className="w-full mt-6 py-2 text-slate-400 font-black text-[10px] uppercase hover:text-indigo-600 transition-all border-t border-slate-50 dark:border-slate-800 pt-4">
               SINCRONIZACIÓN BANCARIA: ACTIVA
             </button>
           </div>
        </div>
      </div>
    </div>
  );
};

const darkModeSupported = () => document.querySelector('.dark') !== null;

export default Finance;
