
import React from 'react';
import { MOCK_HABITS } from '../constants';
import { Flame, CheckCircle2, Circle, MoreVertical, TrendingUp, Info } from 'lucide-react';

const Habits: React.FC = () => {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-slate-900">Construcción de Hábitos</h2>
          <p className="text-slate-500 mt-1">La consistencia es la clave del cambio duradero.</p>
        </div>
        <button className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-bold shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all">
          Nuevo Hábito
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          {MOCK_HABITS.map(habit => (
            <div key={habit.id} className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm transition-all hover:shadow-md hover:border-indigo-100 group">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${habit.streak > 3 ? 'bg-orange-100 text-orange-600' : 'bg-indigo-100 text-indigo-600'}`}>
                    {habit.streak > 3 ? <Flame size={24} /> : <CheckCircle2 size={24} />}
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-slate-800">{habit.name}</h3>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-orange-500">RACHA DE {habit.streak} DÍAS</span>
                      <span className="text-xs font-medium text-slate-400">• Meta: {habit.targetDays} días</span>
                    </div>
                  </div>
                </div>
                <button className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-50">
                  <MoreVertical size={20} />
                </button>
              </div>

              <div className="flex items-center justify-between gap-2 mb-4 overflow-x-auto pb-2 sm:pb-0 no-scrollbar">
                {habit.completed.map((done, i) => (
                  <div key={i} className="flex flex-col items-center gap-2 min-w-[40px]">
                    <span className="text-[10px] font-bold text-slate-400 uppercase">{['L','M','X','J','V','S','D'][i % 7]}</span>
                    <button className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${done ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-100' : 'bg-slate-50 text-slate-300 border border-slate-200 hover:border-emerald-300'}`}>
                      {done ? <CheckCircle2 size={20} /> : <Circle size={20} />}
                    </button>
                  </div>
                ))}
                {/* Marcadores futuros */}
                {[1, 2].map(i => (
                  <div key={`placeholder-${i}`} className="flex flex-col items-center gap-2 min-w-[40px] opacity-30">
                     <span className="text-[10px] font-bold text-slate-300 uppercase">...</span>
                     <div className="w-10 h-10 rounded-xl border border-dashed border-slate-300" />
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between mt-6 pt-6 border-t border-slate-50">
                <div className="flex -space-x-2">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="w-8 h-8 rounded-full border-2 border-white bg-slate-200" />
                  ))}
                  <div className="w-8 h-8 rounded-full border-2 border-white bg-indigo-50 flex items-center justify-center text-[10px] font-bold text-indigo-600">
                    +12
                  </div>
                </div>
                <p className="text-xs text-slate-400 font-medium italic">¡Únete a otros 15 en este hábito!</p>
              </div>
            </div>
          ))}
        </div>

        <div className="space-y-8">
           <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm text-center">
             <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
               <TrendingUp size={32} />
             </div>
             <h3 className="text-xl font-bold mb-2">Consistencia Global</h3>
             <p className="text-5xl font-black text-slate-900 mb-2">87%</p>
             <p className="text-sm text-slate-400 font-medium px-4 leading-relaxed">Tu consistencia ha subido un 12% desde el mes pasado. ¡Mantén el ritmo!</p>
             <div className="mt-8 pt-8 border-t border-slate-100 flex justify-between gap-4">
               <div>
                 <p className="text-xs text-slate-400 font-bold uppercase mb-1">Activos</p>
                 <p className="text-xl font-bold text-slate-900">12</p>
               </div>
               <div>
                 <p className="text-xs text-slate-400 font-bold uppercase mb-1">Archivados</p>
                 <p className="text-xl font-bold text-slate-900">5</p>
               </div>
               <div>
                 <p className="text-xs text-slate-400 font-bold uppercase mb-1">Fallidos</p>
                 <p className="text-xl font-bold text-slate-900">2</p>
               </div>
             </div>
           </div>

           <div className="bg-slate-900 text-white rounded-3xl p-6 relative overflow-hidden">
             <div className="relative z-10">
               <div className="flex items-center gap-2 text-indigo-400 mb-3">
                 <Info size={18} />
                 <span className="text-xs font-bold uppercase tracking-widest">Tip Científico</span>
               </div>
               <h4 className="font-bold mb-3 leading-snug">La Regla de los 2 Minutos</h4>
               <p className="text-slate-400 text-sm leading-relaxed mb-6">
                 Si un hábito toma menos de dos minutos, empiézalo de inmediato. La parte más difícil suele ser simplemente comenzar.
               </p>
               <button className="w-full py-2.5 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl transition-all">
                 Leer Artículo
               </button>
             </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Habits;
