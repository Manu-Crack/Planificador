
import React, { useState, useEffect } from 'react';
import { TrendingUp, Clock, Target, ShieldCheck, Zap, Info, Heart } from 'lucide-react';
import { MOCK_BUDGETS, MOCK_TASKS, MOCK_HABITS } from '../constants';
import { analyzeLifeData } from '../services/geminiService';
import { AppSection } from '../types';

interface DashboardProps {
  setActiveSection: (section: AppSection) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ setActiveSection }) => {
  const [aiInsights, setAiInsights] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchInsights = async () => {
      setLoading(true);
      const data = await analyzeLifeData({ MOCK_BUDGETS, MOCK_TASKS, MOCK_HABITS });
      setAiInsights(data.insights || []);
      setLoading(false);
    };
    fetchInsights();
  }, []);

  const totalSpent = MOCK_BUDGETS.reduce((acc, curr) => acc + curr.spent, 0);
  const totalLimit = MOCK_BUDGETS.reduce((acc, curr) => acc + curr.limit, 0);
  const taskCompletion = (MOCK_TASKS.filter(t => t.status === 'Completada').length / MOCK_TASKS.length) * 100;

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-3xl font-black tracking-tight text-slate-900 uppercase">Status del Sistema</h2>
          <p className="text-slate-500 mt-1">Control de superusuario activo para Lima, Perú.</p>
        </div>
        <div className="text-sm font-bold bg-white px-4 py-2 rounded-full border border-slate-200 text-slate-600 flex items-center gap-2">
          <Clock size={16} className="text-indigo-500" />
          <span>Lunes, 19 de Enero, 2026</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Presupuesto Mensual" value={`S/. ${totalSpent}`} subtitle={`de S/. ${totalLimit}`} progress={(totalSpent/totalLimit)*100} color="indigo" icon={TrendingUp} onClick={() => setActiveSection(AppSection.Finance)} />
        <StatCard title="Eficiencia de Tareas" value={`${Math.round(taskCompletion)}%`} subtitle="Rendimiento hoy" progress={taskCompletion} color="blue" icon={Target} onClick={() => setActiveSection(AppSection.Schedule)} />
        <StatCard title="Racha Habitual" value="5 días" subtitle="Dedicación focalizada" progress={85} color="emerald" icon={Zap} onClick={() => setActiveSection(AppSection.Habits)} />
        <StatCard title="Estado Ético" value="9.2/10" subtitle="Consistencia Admin" progress={92} color="rose" icon={ShieldCheck} onClick={() => setActiveSection(AppSection.Values)} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm relative overflow-hidden">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold flex items-center gap-2">
                <SparkleIcon />
                Núcleo de Inteligencia Gemini
              </h3>
              <span className="text-[10px] font-black px-2 py-1 bg-emerald-100 text-emerald-700 rounded-lg uppercase">Análisis Pro Activo</span>
            </div>

            {loading ? (
              <div className="flex flex-col gap-4">
                {[1, 2, 3].map(i => (
                  <div key={i} className="h-20 w-full bg-slate-50 animate-pulse rounded-2xl" />
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {aiInsights.map((insight, idx) => (
                  <div key={idx} className="group flex gap-4 p-5 rounded-2xl bg-slate-50 border border-transparent hover:border-slate-200 hover:bg-white hover:shadow-md transition-all">
                    <div className={`shrink-0 w-12 h-12 rounded-xl flex items-center justify-center ${insight.priority === 'Alta' ? 'bg-rose-100 text-rose-600' : 'bg-slate-900 text-white'}`}>
                      <Info size={24} />
                    </div>
                    <div>
                      <h4 className="font-black text-slate-800 uppercase text-xs tracking-wider mb-1">{insight.title}</h4>
                      <p className="text-sm text-slate-500 leading-relaxed font-medium">{insight.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
              <h3 className="font-bold mb-4 flex items-center justify-between">
                Línea de Tiempo
                <span className="text-[10px] text-indigo-600 font-bold">3 CRÍTICOS</span>
              </h3>
              <div className="space-y-3">
                {MOCK_TASKS.slice(0, 3).map(task => (
                  <div key={task.id} className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100">
                    <div className="w-2 h-2 rounded-full bg-slate-900" />
                    <div className="flex-1">
                      <p className="text-sm font-bold text-slate-800">{task.title}</p>
                      <p className="text-[10px] text-slate-400 font-bold uppercase">{task.dueDate}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="bg-slate-900 text-white rounded-3xl p-6 border border-slate-800 shadow-xl overflow-hidden relative group">
              <div className="relative z-10">
                <h3 className="font-bold mb-2">Monitor de Proyectos</h3>
                <p className="text-xs text-slate-400 mb-6">Operando con recursos ilimitados</p>
                <div className="space-y-4">
                   <div>
                    <div className="flex justify-between text-[10px] font-bold mb-1 uppercase tracking-widest text-indigo-300">
                      <span>LIFE OS CORE</span>
                      <span>90%</span>
                    </div>
                    <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-400 w-[90%]" />
                    </div>
                   </div>
                   <div>
                    <div className="flex justify-between text-[10px] font-bold mb-1 uppercase tracking-widest text-emerald-300">
                      <span>FINANZAS PERSONALES</span>
                      <span>40%</span>
                    </div>
                    <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-400 w-[40%]" />
                    </div>
                   </div>
                </div>
              </div>
              <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-20 transition-opacity">
                <ShieldCheck size={120} />
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-8">
           <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
             <h3 className="font-bold mb-4 text-slate-900">Flujo de Soles (S/.)</h3>
             <div className="space-y-5">
               {MOCK_BUDGETS.slice(0, 3).map(budget => (
                 <div key={budget.category}>
                   <div className="flex justify-between text-xs mb-2 font-bold uppercase tracking-tight">
                     <span className="text-slate-500">{budget.category}</span>
                     <span className="text-slate-900">S/. {budget.spent} / {budget.limit}</span>
                   </div>
                   <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                     <div 
                      className={`h-full rounded-full transition-all duration-1000 ${budget.spent/budget.limit > 0.9 ? 'bg-rose-500' : 'bg-slate-900'}`} 
                      style={{ width: `${Math.min(100, (budget.spent/budget.limit)*100)}%` }}
                     />
                   </div>
                 </div>
               ))}
               <button 
                onClick={() => setActiveSection(AppSection.Finance)}
                className="w-full py-3 bg-slate-900 text-white font-bold text-xs rounded-xl hover:bg-indigo-600 transition-all shadow-lg shadow-slate-200 uppercase tracking-widest"
               >
                 CENTRO DE FINANZAS
               </button>
             </div>
           </div>

           <div className="bg-indigo-600 text-white rounded-3xl p-6 shadow-xl shadow-indigo-100 relative overflow-hidden group cursor-pointer" onClick={() => setActiveSection(AppSection.Values)}>
             <div className="relative z-10">
               <ShieldCheck className="mb-4 text-white" size={32} />
               <h3 className="font-black text-lg mb-2 uppercase tracking-tight">Núcleo Ético</h3>
               <p className="text-indigo-100 text-xs mb-6 leading-relaxed font-medium">Sincronización de valores pendiente. ¿Ejecutar auditoría de comportamiento?</p>
               <button className="px-6 py-2 bg-white text-indigo-700 font-bold text-xs rounded-xl hover:shadow-2xl transition-all uppercase tracking-widest">
                 AUDITAR
               </button>
             </div>
             <div className="absolute -bottom-8 -right-8 opacity-20 transform rotate-12 group-hover:scale-110 transition-transform">
               <Heart size={160} />
             </div>
           </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, subtitle, progress, color, icon: Icon, onClick }: any) => {
  const colors: any = {
    indigo: 'bg-indigo-500',
    blue: 'bg-blue-500',
    emerald: 'bg-emerald-500',
    rose: 'bg-rose-500',
  };

  return (
    <div onClick={onClick} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm group hover:border-slate-900 hover:shadow-xl transition-all cursor-pointer">
      <div className="flex justify-between items-start mb-4">
        <div className={`p-3 rounded-2xl bg-slate-100 text-slate-900 group-hover:bg-slate-900 group-hover:text-white transition-all`}>
          <Icon size={24} />
        </div>
        <div className="flex items-center gap-1 text-emerald-600 font-black text-xs">
          <TrendingUp size={14} />
          <span>OPTIMAL</span>
        </div>
      </div>
      <h4 className="text-slate-400 text-[10px] font-black uppercase tracking-widest">{title}</h4>
      <p className="text-2xl font-black mt-1 text-slate-900">{value}</p>
      <p className="text-[10px] text-slate-400 mt-1 font-bold">{subtitle}</p>
      <div className="mt-4 h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
        <div className={`h-full ${colors[color]} rounded-full transition-all duration-1000`} style={{ width: `${progress}%` }} />
      </div>
    </div>
  );
};

const SparkleIcon = () => (
  <svg className="w-5 h-5 text-indigo-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 3l1.912 5.813a2 2 0 001.275 1.275L21 12l-5.813 1.912a2 2 0 00-1.275 1.275L12 21l-1.912-5.813a2 2 0 00-1.275-1.275L3 12l5.813-1.912a2 2 0 001.275-1.275L12 3z" />
  </svg>
);

export default Dashboard;
